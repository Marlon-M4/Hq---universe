// Interações do HQ Universe: filtros, pesquisa, detalhes e formulário.
const cards = [...document.querySelectorAll(".hq-card")];
const filterButtons = [...document.querySelectorAll(".filter-btn")];
const searchInput = document.querySelector("#busca");
const emptyState = document.querySelector("#sem-resultados");
let activeFilter = "todos";

function filterComics() {
    const term = searchInput.value.trim().toLocaleLowerCase("pt-BR");
    let visibleCount = 0;

    cards.forEach((card) => {
        const publisher = card.dataset.publisher;
        const searchableText = `${card.dataset.title} ${card.dataset.hero} ${publisher}`.toLocaleLowerCase("pt-BR");
        const matchesPublisher = activeFilter === "todos" || publisher === activeFilter;
        const matchesSearch = searchableText.includes(term);
        const shouldShow = matchesPublisher && matchesSearch;

        card.hidden = !shouldShow;
        if (shouldShow) visibleCount++;
    });

    emptyState.hidden = visibleCount !== 0;
}

filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
        activeFilter = button.dataset.filter;
        filterButtons.forEach((item) => {
            const isActive = item === button;
            item.classList.toggle("active", isActive);
            item.setAttribute("aria-pressed", String(isActive));
        });
        filterComics();
    });
});

searchInput.addEventListener("input", filterComics);

// Janela de detalhes de cada HQ.
const modal = document.querySelector("#details-modal");
const modalTitle = document.querySelector("#modal-title");
const modalPublisher = document.querySelector("#modal-publisher");
const modalDescription = document.querySelector("#modal-description");

document.querySelectorAll(".details-btn").forEach((button) => {
    button.addEventListener("click", () => {
        const [title, publisher, description] = button.dataset.details.split("|");
        modalTitle.textContent = title;
        modalPublisher.textContent = publisher;
        modalDescription.textContent = description;

        if (typeof modal.showModal === "function") {
            modal.showModal();
        } else {
            alert(`${title} — ${description}`);
        }
    });
});

function closeModal() {
    if (modal.open) modal.close();
}
document.querySelector("#modal-close").addEventListener("click", closeModal);
document.querySelector("#modal-ok").addEventListener("click", closeModal);
modal.addEventListener("click", (event) => {
    if (event.target === modal) closeModal();
});

// Menu responsivo para celulares.
const menuToggle = document.querySelector("#menu-toggle");
const menu = document.querySelector("#menu");

menuToggle.addEventListener("click", () => {
    const isOpen = menu.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Fechar menu" : "Abrir menu");
});

menu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
        menu.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Abrir menu");
    });
});

// Demonstração escolar: valida o formulário no navegador e mostra confirmação.
// Para enviar mensagens de verdade, será necessário conectar um serviço/backend.
document.querySelector("#contact-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const name = document.querySelector("#nome").value.trim();
    const status = document.querySelector("#form-status");

    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    status.textContent = `Valeu, ${name}! Sua mensagem foi validada neste exemplo.`;
    form.reset();
});
